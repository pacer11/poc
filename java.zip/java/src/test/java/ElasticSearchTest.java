/**
 * Created by jfaniyi on 2/21/17.
 */
public class ElasticSearchTest {
}
